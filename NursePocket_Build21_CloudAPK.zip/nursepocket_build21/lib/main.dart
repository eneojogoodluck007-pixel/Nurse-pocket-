import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

void main() => runApp(const NursePocketApp());

const navy = Color(0xFF10283F);
const teal = Color(0xFF12B8B0);
const ice = Color(0xFFEAF7F7);

class NursePocketApp extends StatelessWidget {
  const NursePocketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NursePocket',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: teal),
        scaffoldBackgroundColor: ice, appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
        useMaterial3: true),
      home: const MainShell(),
    );
  }
}


class LearningModule {
  final String title;
  final String subtitle;
  final IconData icon;
  const LearningModule(this.title, this.subtitle, this.icon);
}


const modules = <LearningModule>[
  LearningModule('Disease Library', 'Understand common diseases and conditions', Icons.biotech),
  LearningModule('Drug Reference', 'Learn drug classes and safe principles', Icons.medication),
  LearningModule('Anatomy & Physiology', 'Explore body systems and functions', Icons.favorite),
  LearningModule('Nursing Skills', 'Study nursing procedures and care skills', Icons.health_and_safety),
  LearningModule('Medical Terminology', 'Build your healthcare vocabulary', Icons.menu_book),
  LearningModule('Maternal & Child Health', 'Mother, newborn and child care', Icons.child_care),
  LearningModule('Emergency & First Aid', 'Recognize emergencies and first responses', Icons.emergency),
  LearningModule('Nutrition', 'Nutrients, diets and nutrition basics', Icons.restaurant),
  LearningModule('Mental Health', 'Mental wellbeing and therapeutic communication', Icons.psychology),
];

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int currentTab = 0;
  final completed = <String>{};
  final bookmarks = <String>{};
  final tabs = const ['Home', 'Library', 'Quiz', 'Progress', 'Profile'];

  Widget page() {
    switch (currentTab) {
      case 1: return LibraryPage(onOpen: openModule, bookmarks: bookmarks);
      case 2: return const QuizPage();
      case 3: return ProgressPage(completed: completed);
      case 4: return ProfilePage(bookmarks: bookmarks);
      default: return HomePage(onOpen: openModule, completed: completed);
    }
  }

  void openModule(LearningModule module) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ModulePage(
      module: module,
      isSaved: bookmarks.contains(module.title),
      isDone: completed.contains(module.title),
      onSave: () => setState(() { bookmarks.contains(module.title) ? bookmarks.remove(module.title) : bookmarks.add(module.title); }),
      onComplete: () => setState(() => completed.add(module.title)),
    )));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: page()),
    bottomNavigationBar: NavigationBar(selectedIndex: currentTab, onDestinationSelected: (i) => setState(() => currentTab = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.library_books_outlined), label: 'Library'),
        NavigationDestination(icon: Icon(Icons.quiz_outlined), label: 'Quiz'),
        NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Progress'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
      ]),
  );
}


class HomePage extends StatelessWidget {
  final void Function(LearningModule) onOpen;
  final Set<String> completed;
  const HomePage({super.key, required this.onOpen, required this.completed});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [SvgPicture.asset('assets/nursepocket-logo.svg', width: 54, height: 54), const SizedBox(width: 10),
      const Expanded(child: Text('NursePocket', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: navy)))]),
    const SizedBox(height: 16),
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(18)),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Welcome to NursePocket', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
        SizedBox(height: 6), Text('Healthcare knowledge, right in your pocket.', style: TextStyle(color: Colors.white70))])),
    const SizedBox(height: 18),
    Text('Learning modules', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: modules.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.12),
      itemBuilder: (context, i) { final m = modules[i]; return InkWell(onTap: () => onOpen(m), borderRadius: BorderRadius.circular(16),
        child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(m.icon, size: 30, color: teal), const SizedBox(height: 8), Text(m.title, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)),
            const SizedBox(height: 4), Text('${completed.contains(m.title) ? 'Completed' : 'Explore module'}', style: const TextStyle(fontSize: 12, color: Colors.black54))]))); }),
    const SizedBox(height: 18),
    Card(child: ListTile(leading: const Icon(Icons.emoji_events, color: teal), title: const Text('Your progress'), subtitle: Text('${completed.length} of ${modules.length} modules marked complete'),
      trailing: const Icon(Icons.chevron_right))),
  ]);
}


class LibraryPage extends StatelessWidget {
  final void Function(LearningModule) onOpen;
  final Set<String> bookmarks;
  const LibraryPage({super.key, required this.onOpen, required this.bookmarks});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Library', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: navy)),
    const SizedBox(height: 10),
    ...modules.map((m) => Card(child: ListTile(leading: Icon(m.icon, color: teal), title: Text(m.title), subtitle: Text(m.subtitle), trailing: Icon(bookmarks.contains(m.title) ? Icons.bookmark : Icons.chevron_right), onTap: () => onOpen(m)))),
  ]);
}


class ModulePage extends StatelessWidget {
  final LearningModule module;
  final bool isSaved;
  final bool isDone;
  final VoidCallback onSave;
  final VoidCallback onComplete;
  const ModulePage({super.key, required this.module, required this.isSaved, required this.isDone, required this.onSave, required this.onComplete});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(module.title)), body: ListView(padding: const EdgeInsets.all(18), children: [
    Icon(module.icon, size: 60, color: teal), const SizedBox(height: 12), Text(module.subtitle, style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 18), const Text('Module introduction', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('This module is a learning area for nursing and healthcare knowledge. Detailed lessons, source-checked references, illustrations, and quizzes will be added in the content development stages.'),
    const SizedBox(height: 16), const Text('Study safely', style: TextStyle(fontWeight: FontWeight.bold)),
    const Text('Use this app for education. Clinical care and procedures must follow local protocols and qualified supervision.'),
    const SizedBox(height: 22), FilledButton.icon(onPressed: isDone ? null : onComplete, icon: const Icon(Icons.check_circle), label: Text(isDone ? 'Marked complete' : 'Mark module complete')),
    OutlinedButton.icon(onPressed: onSave, icon: Icon(isSaved ? Icons.bookmark_remove : Icons.bookmark_add), label: Text(isSaved ? 'Remove bookmark' : 'Bookmark module')),
  ]));
}


class QuizPage extends StatelessWidget {
  const QuizPage({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.quiz, size: 60, color: teal), const SizedBox(height: 12), const Text('Quick Practice', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: navy)),
    const SizedBox(height: 8), const Text('The quiz engine and reviewed question bank will be connected in a later build.', textAlign: TextAlign.center),
  ])));
}


class ProgressPage extends StatelessWidget {
  final Set<String> completed;
  const ProgressPage({super.key, required this.completed});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Your progress', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${completed.length} / ${modules.length} modules completed', style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 12), LinearProgressIndicator(value: completed.length / modules.length, color: teal), const SizedBox(height: 8), Text('${((completed.length / modules.length) * 100).round()}% complete')]))
  ]));
}


class ProfilePage extends StatelessWidget {
  final Set<String> bookmarks;
  const ProfilePage({super.key, required this.bookmarks});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Profile', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 14),
    const Card(child: ListTile(leading: CircleAvatar(backgroundColor: teal, child: Icon(Icons.person, color: Colors.white)), title: Text('Learner profile'), subtitle: Text('Local prototype profile'))),
    Card(child: ListTile(leading: const Icon(Icons.bookmark, color: teal), title: const Text('Saved modules'), subtitle: Text('${bookmarks.length} bookmarked'))),
    const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('About NursePocket'), subtitle: Text('Healthcare knowledge, right in your pocket.'))),
  ]);
}
