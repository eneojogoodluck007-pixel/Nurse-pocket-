# NursePocket Build 21 — Cloud Android APK Build

This package uses GitHub Actions to compile the Flutter app in the cloud. You can trigger the build using a phone; you do not need Flutter installed locally.

## Contents
- `lib/` — Flutter application source
- `assets/` — NursePocket logo
- `pubspec.yaml` — dependencies
- `.github/workflows/android-apk.yml` — automatic cloud build workflow

## Build using Android phone
1. Extract this ZIP on your phone or keep it ready for upload.
2. Open GitHub in Chrome and sign in (create an account if needed).
3. Create a new repository named `nursepocket`, set it to **Public** for simplest GitHub Actions access, and create it with no README/template.
4. Upload the package's files and folders into the repository. Ensure the `.github/workflows/android-apk.yml` path is present. (GitHub web upload may not handle nested files easily on mobile; if so, use a browser in Desktop site mode.)
5. Open the repository's **Actions** tab. If prompted, enable workflows.
6. Select **Build NursePocket Android APK**. Press **Run workflow** if the manual trigger is shown, or make a commit to `main` to trigger it automatically.
7. Wait for the run to finish successfully. Open the completed workflow run, scroll to **Artifacts**, and download `nursepocket-debug-apk`.
8. Extract the artifact ZIP, then tap `app-debug.apk` to install. Android may ask permission to install apps from that browser/file manager; only enable it for the trusted app you are using, then turn it off again after installation.

## Limitations
- This is a debug APK, not a release-signed Play Store build.
- This build workflow does not guarantee compilation until the cloud run succeeds.
- The app is an early prototype. Content is incomplete and not clinical decision support.
- Keep the repository private if you do not want your source publicly visible; GitHub Actions availability/minutes depend on your plan and repository settings.
