import 'package:shared_preferences/shared_preferences.dart';

class AppState {
  static const _bookmarksKey='np_bookmarks_v1';
  static const _completedKey='np_completed_v1';
  static const _quizKey='np_quiz_scores_v1';
  static final Set<String> bookmarks={};
  static final Set<String> completed={};
  static final List<int> quizScores=[];
  static Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    bookmarks..clear()..addAll(p.getStringList(_bookmarksKey)??[]);
    completed..clear()..addAll(p.getStringList(_completedKey)??[]);
    quizScores..clear()..addAll(p.getStringList(_quizKey)?.map(int.parse)??[]);
  }
  static Future<void> toggleBookmark(String id) async {
    if(!bookmarks.add(id)) bookmarks.remove(id);
    final p=await SharedPreferences.getInstance(); await p.setStringList(_bookmarksKey,bookmarks.toList());
  }
  static Future<void> markComplete(String id) async {
    completed.add(id); final p=await SharedPreferences.getInstance(); await p.setStringList(_completedKey,completed.toList());
  }
  static Future<void> saveScore(int score) async {
    quizScores.add(score); final p=await SharedPreferences.getInstance(); await p.setStringList(_quizKey,quizScores.map((e)=>e.toString()).toList());
  }
  static Future<void> clearProgress() async {
    bookmarks.clear(); completed.clear(); quizScores.clear();
    final p=await SharedPreferences.getInstance(); await p.remove(_bookmarksKey); await p.remove(_completedKey); await p.remove(_quizKey);
  }
}
