import 'package:flutter/material.dart';

class NursingModule {
  final String title, subtitle;
  final IconData icon;
  final List<Lesson> lessons;
  const NursingModule(this.title, this.subtitle, this.icon, this.lessons);
}

class Lesson {
  final String title, overview, objectives, keyPoints, nursingNotes, caution;
  const Lesson({required this.title, required this.overview, required this.objectives,
    required this.keyPoints, required this.nursingNotes, required this.caution});
}
Lesson lesson(String title, String module) => Lesson(
  title: title,
  overview: '$title is included in the $module learning module. This lesson outline is a study starting point. A complete reviewed lesson will include definitions, relevant physiology, assessment findings, investigations, management principles, complications, prevention and revision questions where applicable.',
  objectives: '• Explain the meaning of $title.\n• Identify key concepts and terminology.\n• Describe its relevance to safe nursing care.',
  keyPoints: 'Study the definition, causes or mechanisms, classifications, assessment, and prevention or management principles relevant to this topic. Confirm clinical details against current reliable references and local protocols.',
  nursingNotes: 'Use appropriate assessment, documentation, communication, infection prevention and patient education. Work within your training and scope, and seek supervision when needed.',
  caution: 'Educational outline only—not a clinical decision tool. It is not a substitute for a qualified clinician, supervised practice, current guidelines or local protocols.');

final nursingModules = <NursingModule>[
  NursingModule('Disease Library','Diseases and conditions',Icons.health_and_safety,[
    'Malaria','Typhoid Fever','Hypertension','Diabetes Mellitus','Peptic Ulcer Disease','Pneumonia','HIV/AIDS','Tuberculosis','Asthma','Diarrhoeal Diseases','Anaemia','Urinary Tract Infection','Hepatitis','Sickle Cell Disease','Stroke'
  ].map((t)=>lesson(t,'Disease Library')).toList()),
  NursingModule('Drug Reference','Medicines and drug classes',Icons.medication,[
    'Analgesics','Antibiotics','Antimalarials','Antihypertensives','Antidiabetics','Gastrointestinal Medicines','Antifungals','Antivirals','Antihistamines','Corticosteroids','Anticoagulants','Diuretics','Drug Safety and Medication Rights'
  ].map((t)=>lesson(t,'Drug Reference')).toList()),
  NursingModule('Anatomy & Physiology','Human body systems',Icons.favorite,[
    'Skeletal System','Muscular System','Cardiovascular System','Respiratory System','Digestive System','Nervous System','Endocrine System','Urinary System','Reproductive System','Lymphatic and Immune System','Integumentary System','Special Senses'
  ].map((t)=>lesson(t,'Anatomy & Physiology')).toList()),
  NursingModule('Nursing Skills','Procedures and clinical skills',Icons.medical_services,[
    'Hand Hygiene','Vital Signs','Blood Pressure Measurement','Patient Positioning','Bed Making','Personal Hygiene','Wound Dressing Principles','Medication Safety','Oral Medication Administration','Injection Safety Principles','IV Cannulation Overview','Fluid Balance','Specimen Collection','Catheter Care','Oxygen Therapy','Nebulization','CPR Basics','Blood Glucose Monitoring','Documentation'
  ].map((t)=>lesson(t,'Nursing Skills')).toList()),
  NursingModule('Medical Terminology','Medical words and meanings',Icons.menu_book,[
    'Prefixes','Root Words','Suffixes','Combining Forms','Tachycardia','Bradycardia','Hypoglycaemia','Hypertension','Hepatomegaly','Nephritis','Arthritis','Common Abbreviations'
  ].map((t)=>lesson(t,'Medical Terminology')).toList()),
  NursingModule('Maternal & Child Health','Mother, newborn and child care',Icons.child_care,[
    'Antenatal Care','Pregnancy','Labour and Delivery','Postnatal Care','Newborn Assessment','Apgar Score','Growth and Development','Immunization','Child Nutrition','Danger Signs','Family Planning'
  ].map((t)=>lesson(t,'Maternal & Child Health')).toList()),
  NursingModule('Emergency & First Aid','Urgent care fundamentals',Icons.emergency,[
    'Initial Assessment','Bleeding','Burns','Choking','Seizures','Shock','CPR and AED Awareness','Poisoning','Fractures','Anaphylaxis','Stroke Recognition','Emergency Escalation'
  ].map((t)=>lesson(t,'Emergency & First Aid')).toList()),
  NursingModule('Nutrition','Food, nutrients and health',Icons.restaurant,[
    'Carbohydrates','Proteins','Fats','Vitamins','Minerals','Balanced Diet','Malnutrition','Dehydration','Anaemia and Nutrition','Therapeutic Diet Basics','Nutrition Across the Lifespan'
  ].map((t)=>lesson(t,'Nutrition')).toList()),
  NursingModule('Mental Health','Psychological health and wellbeing',Icons.psychology,[
    'Mental Health Foundations','Anxiety','Depression','Psychosis Overview','Substance Use','Therapeutic Communication','Mental Status Examination','Suicide Risk Awareness','Stress Management','Reducing Stigma'
  ].map((t)=>lesson(t,'Mental Health')).toList()),
];
