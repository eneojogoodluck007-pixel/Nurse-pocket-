# NursePocket (Flutter starter project)

Mobile-first nursing education app prototype. Includes 9 topic modules, module/topic reader pages, topic search, persistent bookmarks/completed topics/quiz scores via SharedPreferences, progress summary, and a five-question practice quiz.

## Build APK with GitHub Actions
1. Upload the project contents to your GitHub repository (including `.github/workflows/build-apk.yml`).
2. Open repository **Actions** tab and enable workflows if prompted.
3. Run **NursePocket Android APK** manually using **Run workflow**, or push to `main`.
4. Wait for the job to finish, open its run, and download the `NursePocket-debug-apk` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on Android. Android may prompt to allow installation from your browser/files app.

## Local build
Requires Flutter SDK and Android toolchain: `flutter pub get`, then `flutter build apk --debug`.

## Current limitations
Lesson entries are structured placeholder study outlines, not clinically reviewed full lessons. The sample quiz has five basic questions only. Backup/restore, rich content, detailed CBT bank, and clinical review workflow are not implemented. This is educational only and must not guide patient treatment. Source has not been compiled or device-tested in this environment.
